/*Q1. C++ Assignments | 2D Arrays - 2 | Week 6
Write a program to print the elements of both the diagonals in a square matrix.
Input 1:
1 2 3
4 5 6
7 8 9
Output 1:
1 3
5
7 9
*/
#include <iostream>
#include <vector>

using namespace std;

void printDiagonals(const vector<vector<int>>& matrix) {
    int n = matrix.size();
    
    // Print elements of the main diagonal
    cout << "Main Diagonal:" << endl;
    for (int i = 0; i < n; ++i) {
        cout << matrix[i][i] << " ";
    }
    cout << endl;
    
    // Print elements of the secondary diagonal
    cout << "Secondary Diagonal:" << endl;
    for (int i = 0; i < n; ++i) {
        cout << matrix[i][n - 1 - i] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter the size of the square matrix: ";
    cin >> n;
    
    vector<vector<int>> matrix(n, vector<int>(n));
    
    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> matrix[i][j];
        }
    }
    
    // Print diagonals
    printDiagonals(matrix);
    
    return 0;
}

/*Q2.Write a program to rotate the matrix by 90 degrees anti-clockwise.
Input 1:
1 2 3
4 5 6
7 8 9
Output 1:
3 6 9
2 5 8
1 4 7 */

#include <iostream>
#include <vector>

using namespace std;

void rotateMatrix(vector<vector<int>>& matrix) {
    int n = matrix.size();
    // Transpose the matrix
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            swap(matrix[i][j], matrix[j][i]);
        }
    }

    // Reverse each row
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n / 2; ++j) {
            swap(matrix[i][j], matrix[i][n - 1 - j]);
        }
    }
}

int main() {
    int n;
    cout << "Enter the size of the square matrix: ";
    cin >> n;

    vector<vector<int>> matrix(n, vector<int>(n));

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> matrix[i][j];
        }
    }

    // Rotate the matrix
    rotateMatrix(matrix);

    // Print the rotated matrix
    cout << "Rotated Matrix:" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}


/*Q3 -Write a program to print the matrix in wave form.
Input :
1 2 3
4 5 6
7 8 9
Output : 7 4 1 2 5 8 9 6 3
*/

#include <iostream>
#include <vector>

using namespace std;

void printWaveForm(const vector<vector<int>>& matrix) {
    int rows = matrix.size();
    int cols = matrix[0].size();
    
    for (int col = 0; col < cols; ++col) {
        if (col % 2 == 0) {
            for (int row = 0; row < rows; ++row) {
                cout << matrix[row][col] << " ";
            }
        } else {
            for (int row = rows - 1; row >= 0; --row) {
                cout << matrix[row][col] << " ";
            }
        }
    }
}

int main() {
    int rows, cols;
    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    vector<vector<int>> matrix(rows, vector<int>(cols));

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> matrix[i][j];
        }
    }

    cout << "Wave Form Output:" << endl;
    printWaveForm(matrix);

    return 0;
}

/* Q4-Given a positive integer n, generate a n x n matrix filled with elements from 1 to n2 in spiral order.
Input 1: n = 3
Output 1: [[1,2,3],[8,9,4],[7,6,5]]
Input 2: n = 1
Output 2: [[1]]

*/
#include <iostream>
#include <vector>

using namespace std;

vector<vector<int>> generateSpiralMatrix(int n) {
    vector<vector<int>> matrix(n, vector<int>(n, 0));
    
    int num = 1;
    int left = 0, right = n - 1, top = 0, bottom = n - 1;
    
    while (num <= n * n) {
        // Traverse right
        for (int i = left; i <= right; ++i) {
            matrix[top][i] = num++;
        }
        top++;
        
        // Traverse down
        for (int i = top; i <= bottom; ++i) {
            matrix[i][right] = num++;
        }
        right--;
        
        // Traverse left
        for (int i = right; i >= left; --i) {
            matrix[bottom][i] = num++;
        }
        bottom--;
        
        // Traverse up
        for (int i = bottom; i >= top; --i) {
            matrix[i][left] = num++;
        }
        left++;
    }
    
    return matrix;
}

int main() {
    int n;
    cout << "Enter a positive integer n: ";
    cin >> n;
    
    vector<vector<int>> spiralMatrix = generateSpiralMatrix(n);
    
    cout << "Generated Spiral Matrix:" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << spiralMatrix[i][j] << " ";
        }
        cout << endl;
    }
    
    return 0;
}

/*Q5-Predict the output :
int main(){
int a[][2] = {{1,2},{3,4}};
int i, j;
for (i = 0; i < 2; i++)
for (j = 0; j < 2; j++)
cout << a[i][j];
return 0;
}
*/

//OUTPUT=1234

